package com.college;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCollegeManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartCollegeManagementApplication.class, args);
    }
}
