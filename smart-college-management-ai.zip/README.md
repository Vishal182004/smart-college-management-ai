# Smart College Management System with AI Features

This project is aimed at building a **Smart College Management System** enhanced with **AI features**.  

## Features (Planned)
- Student & Faculty Management
- Attendance Tracking
- Course Management
- AI-based Analytics
- Chatbot for Student Queries
- Smart Timetable Scheduling

## Tech Stack
- **Backend**: Java Spring Boot
- **Frontend**: React.js
- **Database**: MySQL
- **AI Integration**: Python APIs

## How to Run (later when code is complete)
```bash
mvn spring-boot:run
```
